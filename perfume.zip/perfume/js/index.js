$(function(){
            
         
        
              
    //스와이퍼
    var mySwiper = new Swiper('.swiper-container', {
    speed:400,
    autoplay: {
        delay: 1500,
    },
    });

  
});
